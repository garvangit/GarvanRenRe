﻿namespace RenRe.Puzzles.DealLosses
{
    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
